# this module is required for test_nameclash
imports = 1
